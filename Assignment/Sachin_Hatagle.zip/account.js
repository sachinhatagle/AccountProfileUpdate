    // fetch('./data/profile.json')
    //     .then((response) => response.json())
    //     .then((json) => console.log(json));

        import myData from './data/profile.json' assert { type: 'json'}
        console.log(myData);


        const changeData = new Promise((resolve, reject) => {
            resolve(myData);
        })
        changeData.then((value) => {
            nameUpdate(value);
            emailUpdate(value);
            websiteUpdate(value);
            locationUpdate(value);
            imageUpdate(value);
            imageUpdate2(value);
        })

        function nameUpdate(value){
            let newName = document.getElementById("name");
            newName.innerHTML = value.name;

            // console.log(value.name);
        }
        function emailUpdate(value){
            let newEmail = document.getElementById("email");
            newEmail.innerHTML = value.email
        }
        function websiteUpdate(value){
            let newWebsite = document.getElementById("website");
            newWebsite.innerHTML = value.website
        }
        function locationUpdate(value){
            let newLocation = document.getElementById("location");
            newLocation.innerHTML = value.location
        }
        function imageUpdate(value){
            let newImage = document.getElementById("image");
            newImage.src = value.image;
        }
        function imageUpdate2(value){
            let newImage2 = document.getElementById("image2");
            newImage2.src = value.image;
        }
